
document.addEventListener('DOMContentLoaded', () => {
    console.log('Website is ready!');
});
